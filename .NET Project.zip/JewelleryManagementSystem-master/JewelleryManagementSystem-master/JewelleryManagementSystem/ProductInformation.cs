﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JewelleryManagementSystem
{
    public class ProductInformation
    {
        public static string ProductName => "Jewellery Management System";
        public static string ProductVersion => "1.0.0.0";
        public static string OwnerName => "Prathamesh Gokul Sainkar";
        public static string ShopName => "Prathamesh Jewellers";
        public static string OwenrSignature => $"{OwnerName}";
        public static string Address => " Shop No. 6, Yashwant Vihar, Katraj-Kondhwa Rd,Katraj, Pune, 411046";
        public static string PhoneNumber => "1234567890";
    }
}
